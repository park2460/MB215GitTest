from django.test import TestCase
import sqlite3

# Create your tests here.

from sms.models import Order


class SMSTests(TestCase):
    def test_for_json_support(self):
        conn = sqlite3.connect(':memory:')
        cursor = conn.cursor()
        try:
            cursor.execute('SELECT JSON(\'{"a": "b"}\')')
            self.assertIs(False, False)
        except:
            self.assertIs(True, False, "no support for json in sqlite3")
    def test_welcome(self):
        oOrder = Order(phone = '123-456-7890', data={"state":"WELCOMING"})
        aReturn = oOrder.handleInput("hello")
        self.assertEqual(aReturn[0], "Welcome to Jacob's Fries", "welcome message line 1")
        self.assertEqual(aReturn[1], "Toppings are $1 each", "welcome message line 2")
        self.assertEqual(aReturn[2], "Drinks are $2 each", "welcome message line 3")
        self.assertEqual(aReturn[3], "Would you like a SMALL or LARGE?", "welcome message line 4")
        self.assertEqual(oOrder.getState(), "SIZE", "order state should be SIZE")
    def test_small(self):
        oOrder = Order(phone = '123-456-7890', data={"state":"SIZE"})
        aReturn = oOrder.handleInput("small")
        self.assertEqual(aReturn[0], "So far your order total is $2.99")
        self.assertEqual(aReturn[1], "What toppings would you like?", "size message line 1")
        self.assertEqual(aReturn[2], "Please enter a list with commas or NO", "size message line 2")
        self.assertEqual(oOrder.getState(), "TOPPINGS", "order state should be SIZE")
        self.assertEqual(oOrder.getSize(), "small", "size should be small")
        self.assertEqual(oOrder.getPrice(), 2.99, "price should be $2.99")
    def test_large(self):
        oOrder = Order(phone = '123-456-7890', data={"state":"SIZE"})
        aReturn = oOrder.handleInput("large")
        self.assertEqual(aReturn[0], "So far your order total is $3.99")
        self.assertEqual(aReturn[1], "What toppings would you like?", "size message line 1")
        self.assertEqual(aReturn[2], "Please enter a list with commas or NO", "size message line 2")
        self.assertEqual(oOrder.getState(), "TOPPINGS", "order state should be SIZE")
        self.assertEqual(oOrder.getSize(), "large", "size should be large")
        self.assertEqual(oOrder.getPrice(), 3.99, "price should be $3.99")
    def test_medium(self):
        oOrder = Order(phone = '123-456-7890', data={"state":"SIZE"})
        aReturn = oOrder.handleInput("medium")
        self.assertEqual(aReturn[0], "Whoops, looks like we only have small and large", "size message line 1")
        self.assertEqual(aReturn[1], "Please enter a new size", "size message line 2")
        self.assertEqual(oOrder.getState(), "SIZE", "order state should be SIZE")
    def test_toppings(self):
        oOrder = Order(phone = '123-456-7890', data={"state":"SIZE"})
        aReturn = oOrder.handleInput("small")
        aReturn = oOrder.handleInput("gravy, cheese, bacon")
        self.assertEqual(aReturn[0], "So far your order total is $5.99")
        self.assertEqual(aReturn[1], "Would you like a drink with that?", "toppings message line 1")
        self.assertEqual(aReturn[2], "Please type the drinks seperated with commas or NO", "toppings message line 2")
        self.assertEqual(oOrder.getState(), "DRINKS", "order state should be DRINKS")
        self.assertEqual(oOrder.getToppings(), "gravy, cheese, bacon", "toppings should be as entered")
        self.assertEqual(oOrder.getPrice(), 5.99, "price should be $5.99")
    def test_notoppings(self):
        oOrder = Order(phone = '123-456-7890', data={"state":"SIZE"})
        aReturn = oOrder.handleInput("small")
        aReturn = oOrder.handleInput("no")
        self.assertEqual(aReturn[0], "So far your order total is $2.99")
        self.assertEqual(aReturn[1], "Would you like a drink with that?", "toppings message line 1")
        self.assertEqual(aReturn[2], "Please type the drinks seperated with commas or NO", "toppings message line 2")
        self.assertEqual(oOrder.getState(), "DRINKS", "order state should be DRINKS")
        self.assertEqual(oOrder.getToppings(), None, "no toppings were entered")
        self.assertEqual(oOrder.getPrice(), 2.99, "price should be $2.99")
    def test_nodrinks(self):
        oOrder = Order(phone = '123-456-7890', data={"state":"SIZE"})
        aReturn = oOrder.handleInput("small")
        aReturn = oOrder.handleInput("gravy, cheese, bacon")
        aReturn = oOrder.handleInput("no")
        self.assertEqual(aReturn[0], "Thank you for your order", "drinks message line 1")
        self.assertEqual(aReturn[1], "small fry", "drinks message line 2")
        self.assertEqual(aReturn[2], "with gravy, cheese, bacon", "drinks message line 3")
        self.assertEqual(aReturn[3], "Your order total is $5.99 plus HST", "drinks message line 4")
        self.assertEqual(aReturn[4], "Please pick up in 20 minutes", "order complete")
        self.assertEqual(oOrder.getState(), "DONE", "order state should be DONE")
        self.assertEqual(oOrder.getDrinks(), None, "no drinks were entered")
        self.assertEqual(oOrder.getPrice(), 5.99, "price should be $5.99")
    def test_drinks(self):
        oOrder = Order(phone = '123-456-7890', data={"state":"SIZE"})
        aReturn = oOrder.handleInput("small")
        aReturn = oOrder.handleInput("gravy, cheese, bacon")
        aReturn = oOrder.handleInput("pepsi")
        self.assertEqual(aReturn[0], "Thank you for your order", "drinks message line 1")
        self.assertEqual(aReturn[1], "small fry", "drink message line 2")
        self.assertEqual(aReturn[2], "with gravy, cheese, bacon", "drink message line 3")
        self.assertEqual(aReturn[3], "pepsi", "drink message line 4")
        self.assertEqual(aReturn[4], "Your order total is $7.99 plus HST", "drink message line 5")
        self.assertEqual(aReturn[5], "Please pick up in 20 minutes", "order complete")
        self.assertEqual(oOrder.getState(), "DONE", "order state should be DONE")
        self.assertEqual(oOrder.getDrinks(), "pepsi", "drinks as entered")
        self.assertEqual(oOrder.getPrice(), 7.99, "price should be $7.99")
    
    
