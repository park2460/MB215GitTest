from django.db import models

class Order(models.Model):
    # Model has 2 attributes. Phone and a dict called data.
    phone = models.CharField(max_length=255, default='')
    data = models.JSONField()

    def handleInput(self, sInput):
        # this is called for each turn
        # self.data["state"] starts out as WELCOMING
        aReturn = []
        sState = self.data["state"]
        if sState == "WELCOMING":
            aReturn.append("Welcome to Jacob's Fries")
            aReturn.append("Toppings are $1 each")
            aReturn.append("Drinks are $2 each")
            aReturn.append("Would you like a SMALL or LARGE?")
            self.data["state"] = "SIZE"
        elif sState == "SIZE":
            sSize = self.data["size"] = sInput.lower()
            if sSize == "small":
                self.data['price'] = 2.99
            elif sSize == "large":
                self.data['price'] = 3.99
            else:
                aReturn.append("Whoops, looks like we only have small and large")
                aReturn.append("Please enter a new size")
                return aReturn
            aReturn.append("So far your order total is $" + str(self.data['price']))
            aReturn.append("What toppings would you like?")
            aReturn.append("Please enter a list with commas or NO")
            self.data["state"] = "TOPPINGS"
        elif sState == "TOPPINGS":
            if not sInput.lower() == "no":
                sToppings = self.data['toppings'] = sInput.lower()
                sTotalToppings = len(sToppings.split(","))
                self.data['price'] += sTotalToppings
            aReturn.append("So far your order total is $" + str(self.data['price']))
            aReturn.append("Would you like a drink with that?")
            aReturn.append("Please type the drinks seperated with commas or NO")
            self.data['state'] = "DRINKS"
        elif sState == "DRINKS":
            if not sInput.lower() == "no":
                sDrinks = self.data['drinks'] = sInput.lower()
                sTotalDrinks = len(sDrinks.split(",")) * 2
                self.data['price'] += sTotalDrinks
            aReturn.append("Thank you for your order")
            aReturn.append(self.data['size'] + " fry")
            try: 
                aReturn.append("with " + self.data['toppings'])
            except:
                pass
            try: 
                aReturn.append(self.data['drinks'])
            except:
                pass
            aReturn.append("Your order total is $" + str(self.data['price']) + " plus HST")
            aReturn.append("Please pick up in 20 minutes")
            self.data['state'] = "DONE"
        return aReturn

    def isDone(self):
        # this is also called for each turn
        if self.data["state"] == "DONE":
            return True
        else:
            return False
    def getState(self):
        return self.data["state"]
    def getSize(self):
        return self.data["size"]
    def getToppings(self):
        try:
            return self.data["toppings"]
        except: 
            return None
    def getPrice(self):
        return self.data['price']
    def getDrinks(self):
        try:
            return self.data["drinks"]
        except:
            return None
    class Meta:
        # this sets up a SQL index on the phone field
        indexes = [models.Index(fields=['phone'])]

#He wants the total cost for the entire order at the end 
#And wants some sort of increase in price from drink or protein in toppings